const MAX_BASE64_LENGTH = 7_000_000;

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Méthode non autorisée.' });

  const { imageBase64, mediaType = 'image/jpeg' } = req.body || {};
  if (!imageBase64 || typeof imageBase64 !== 'string') return res.status(400).json({ error: 'Image manquante.' });
  if (imageBase64.length > MAX_BASE64_LENGTH) return res.status(413).json({ error: 'Image trop volumineuse.' });
  if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(mediaType)) return res.status(400).json({ error: 'Format d’image non accepté.' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: 'Clé API non configurée.' });

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514',
        max_tokens: 300,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType, data: imageBase64 } },
            { type: 'text', text: "Regarde cette photo d'un objet ou de son étiquette. En une ou deux phrases simples et en français, indique la marque, le type de produit et le modèle ou la référence exacte lorsqu'ils sont visibles. Signale clairement toute incertitude. Ne donne que la description." }
          ]
        }]
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.message || 'Erreur Anthropic');
    const description = (data.content || []).find(x => x.type === 'text')?.text?.trim();
    return res.status(200).json({ description: description || 'Objet non identifié — décris-le manuellement.' });
  } catch (error) {
    console.error(error);
    return res.status(502).json({ error: "L'analyse de l'image a échoué." });
  }
}
