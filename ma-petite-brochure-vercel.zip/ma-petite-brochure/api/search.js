function safeUrl(value) {
  try {
    const url = new URL(value);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '';
  } catch { return ''; }
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Méthode non autorisée.' });
  const { description, language } = req.body || {};
  if (!description || typeof description !== 'string' || description.length > 500) return res.status(400).json({ error: 'Description invalide.' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: 'Clé API non configurée.' });

  const prompt = `Objet : "${description}". Langue souhaitée : ${language || 'Français'}.
Trouve uniquement une notice officielle du fabricant, idéalement un PDF direct ou une page d'assistance officielle. N'utilise un distributeur que s'il est officiellement agréé. Ne prétends jamais avoir trouvé une notice si le modèle exact n'est pas confirmé.
Réponds uniquement avec un JSON valide :
{"found":true ou false,"product":"nom précis","sourceUrl":"URL exacte ou chaîne vide","message":"explication courte en français"}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{ role: 'user', content: prompt }],
        tools: [{ type: 'web_search_20250305', name: 'web_search', max_uses: 5 }]
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.message || 'Erreur Anthropic');
    const text = (data.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n');
    const match = text.replace(/```json|```/g, '').match(/\{[\s\S]*\}/);
    if (!match) throw new Error('Réponse JSON absente');
    const parsed = JSON.parse(match[0]);
    const sourceUrl = safeUrl(parsed.sourceUrl || '');
    return res.status(200).json({
      found: Boolean(parsed.found && sourceUrl),
      product: String(parsed.product || description).slice(0, 200),
      sourceUrl,
      message: String(parsed.message || '').slice(0, 600)
    });
  } catch (error) {
    console.error(error);
    return res.status(502).json({ error: 'La recherche de notice a échoué.' });
  }
}
